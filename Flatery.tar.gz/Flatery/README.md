# Flatery
Flatery is icon theme for linux in flat style licensed under the CC BY-NC-SA 3.0 

<p align="center">
  <img src="https://raw.githubusercontent.com/cbrnix/Flatery/master/cover.png" alt="preview"/>
</p>


## Installation:
Just extract Flattery to ~/.icons or ~/.local/share/icons or /usr/share/icons

 
## Support
If you want support me - 

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=5BXKLL6AVFQ2W)

[![Yandex](http://www.picshare.ru/uploads/191004/Twe65bsSi3.jpg)](https://money.yandex.ru/to/41001796418567)


